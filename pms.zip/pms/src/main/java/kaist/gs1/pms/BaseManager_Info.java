package kaist.gs1.pms;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import kaist.gs1.pms.RepositoryDao_User;

//@Component
public class BaseManager_Info extends BaseManager_Signer {

    @Resource
    protected RepositoryDao_User userRepositoryDao;
    @Resource
    protected RepositoryDao_Company companyRepositoryDao;
    @Resource
    protected RepositoryDao_Partner partnerRepositoryDao;
    @Resource
    protected RepositoryDao_Certificate certificateRepositoryDao;
    @Resource
    protected RepositoryDao_Product productRepositoryDao;
    @Resource
    protected RepositoryDao_Pedigree pedigreeRepositoryDao;
    @Resource
    protected RepositoryDao_Code codeRepositoryDao;
    private static final Logger logger = Logger.getLogger(BaseManager_Info.class);
    private InfoType_Pedigree pedigree = null;
    private InfoType_User user = null;
    private InfoType_Company company = null;
    private InfoType_Partner partner = null;
    
    public Iterable<InfoType_User> getUserList() {
    	return userRepositoryDao.findAll();
    }
    
    public InfoType_User selectUserInfo(String userid) {
        user = userRepositoryDao.findUserByUserID(userid);
        return user;
    }
    
    public boolean saveUserInfo(InfoType_User info) {
    	userRepositoryDao.save(info);
		return true;
    }
    
    public boolean removeUserInfo(InfoType_User info) {
    	userRepositoryDao.delete(info);
		return true;
    }

    public InfoType_Company getCompanyInfo() {
    	if(companyRepositoryDao.count()>0) {
    		company = companyRepositoryDao.findAll().iterator().next();
    	}
        return company;
    }
    
    public boolean saveCompanyInfo(InfoType_Company info) {
    	companyRepositoryDao.save(info);
		return true;
    }
    
    public boolean removeAllCompanyInfo() {
    	if(companyRepositoryDao.count()>0) {
    		companyRepositoryDao.deleteAll();
    	}
		return true;
    }

    public Iterable<InfoType_Partner> getPartnerList() {
    	return partnerRepositoryDao.findAll();
    }
    
    public InfoType_Partner selectPartnerInfo(String pmsAdress) {
        partner = partnerRepositoryDao.findPartnerByPmsAddress(pmsAdress);
        return partner;
    }
    
    public boolean savePartnerInfo(InfoType_Partner info) {
    	partnerRepositoryDao.save(info);
		return true;
    }
    
    public boolean removePartnerInfo(InfoType_Partner info) {
    	partnerRepositoryDao.delete(info);
		return true;
    }
    
    public boolean saveCertificateInfo(InfoType_Certificate info) {
    	InfoType_Certificate certificateAndPrivateKey = this.selectCertificateInfo();
        if(certificateAndPrivateKey != null) {
        	certificateRepositoryDao.deleteAll();
        	certificateRepositoryDao.save(info);
        	return true;
        }
        else {
        	return false;
        }
    }
    
    public InfoType_Certificate selectCertificateInfo() {
    	Iterable<InfoType_Certificate> certs =  certificateRepositoryDao.findAll();
    	return certs.iterator().next();
    }
    
    public Iterable<InfoType_Product> getProductList() {
    	return productRepositoryDao.findAll();
    }
    
    public InfoType_Product selectProductInfo(String productCode) {
        return productRepositoryDao.findProductByProductCode(productCode);
    }
    
    public boolean saveProductInfo(InfoType_Product info) {
    	productRepositoryDao.save(info);
		return true;
    }
    
    public boolean removeProductInfo(InfoType_Product info) {
    	productRepositoryDao.delete(info);
		return true;
    }
    
    public Iterable<InfoType_Pedigree> getPedigreeList() {
    	return pedigreeRepositoryDao.findAll();
    }
    
    public InfoType_Pedigree selectPedigree(String sgtin) {
        pedigree = pedigreeRepositoryDao.findPedigreeBySgtin(sgtin);
        return pedigree;
    }
    
    public boolean savePedigree(InfoType_Pedigree pedigree) {
    	pedigreeRepositoryDao.save(pedigree);
		return true;
    }
    
    public boolean removePedigree(InfoType_Pedigree pedigree) {
    	pedigreeRepositoryDao.delete(pedigree);
		return true;
    }
    
    public Iterable<InfoType_Code> getCodeList() {
    	return codeRepositoryDao.findAll();
    }
}