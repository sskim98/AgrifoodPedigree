package kaist.gs1.pms;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kaist.gs1.pms.MyShellCommand;
import kaist.gs1.pms.InfoType_User;
import kaist.gs1.pms.RepositoryDao_User;

@Controller
public class Controller_Admission{
	@Autowired
	ServletContext servletContext;
	@Autowired
	Manager_UserInfo userManager;
	private static final Logger logger = LoggerFactory.getLogger(Controller_Admission.class);
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login(ModelMap model) {
		model.addAttribute("homeUrl", servletContext.getContextPath() );
		return "login";
	}
	
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(ModelMap model) {
		model.addAttribute("homeUrl", servletContext.getContextPath() );
		return "logout";
	}
	
	@RequestMapping(value = "/signup", method = RequestMethod.POST)
	public String signup(HttpServletRequest request, ModelMap model) {
				
		//logger.info("{}", servletContext.getContextPath() );
		model.addAttribute("homeUrl", servletContext.getContextPath() );
		if(request.getParameter("from").contentEquals("login_page")) {
			return "signup";
		}
		else if(request.getParameter("from").contentEquals("signup_page")){
			model.addAttribute("userid", request.getParameter("userid"));
			model.addAttribute("password", request.getParameter("password"));
			model.addAttribute("username", request.getParameter("username"));
			model.addAttribute("department", request.getParameter("department"));
			model.addAttribute("telephone", request.getParameter("telephone"));
			model.addAttribute("email", request.getParameter("email"));
			
			if(request.getParameter("userid").trim().isEmpty()) {
				model.addAttribute("errorMsg", "Please fill in all the blanks on this form" );
				
				return "signup";
			}
			else if(request.getParameter("password").trim().isEmpty()) {
				model.addAttribute("errorMsg", "Please fill in all the blanks on this form" );
				return "signup";
			}
			else if(request.getParameter("username").trim().isEmpty()) {
				model.addAttribute("errorMsg", "Please fill in all the blanks on this form" );
				return "signup";
			}
			else if(request.getParameter("department").trim().isEmpty()) {
				model.addAttribute("errorMsg", "Please fill in all the blanks on this form" );
				return "signup";
			}
			else if(request.getParameter("telephone").trim().isEmpty()) {
				model.addAttribute("errorMsg", "Please fill in all the blanks on this form" );
				return "signup";
			}
			else if(request.getParameter("email").trim().isEmpty()) {
				model.addAttribute("errorMsg", "Please fill in all the blanks on this form" );
				return "signup";
			}
			else {
				userManager.Signup_UserInfo(
				    			request.getParameter("userid"),
				    			request.getParameter("password"),
				    			request.getParameter("username"),
				    			request.getParameter("department"),
				    			request.getParameter("telephone"),
				    			request.getParameter("email")
				    			);
				return "login";
			}
		}
		return "signup";
	}
	
	@RequestMapping(value = "/accessdenied")
	public String accessdenied(ModelMap model) {
		model.addAttribute("error", "true");
		model.addAttribute("homeUrl", servletContext.getContextPath() );
		return "denied";
	}
}
