package kaist.gs1.pms;

import java.net.InetAddress;
import java.security.Principal;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import javax.net.ssl.X509TrustManager;
import javax.security.cert.X509Certificate;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kaist.gs1.pms.MyShellCommand;
import kaist.gs1.pms.InfoType_User;
import kaist.gs1.pms.RepositoryDao_User;

/**
 * Handles requests for the application home page.
 */
@Controller
public class Controller_CompanyInfo {
	@Autowired
	ServletContext servletContext;
	@Autowired
	Manager_CompanyInfo companyManager;
	
	private static final Logger logger = LoggerFactory.getLogger(Controller_Home.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/company_info", method = RequestMethod.GET)
	public String company_info(HttpServletRequest request, ModelMap model, Principal principal) {
		model.addAttribute("homeUrl", servletContext.getContextPath());
		InfoType_Company company = companyManager.getCompanyInfo();
		model.addAttribute("company", company);
		return "company_info";
	}
	
	@RequestMapping(value = "/change_company", method = RequestMethod.POST)
	public String change_company(HttpServletRequest request, ModelMap model, Principal principal) {
		model.addAttribute("homeUrl", servletContext.getContextPath());
		if(request.getParameter("from").contentEquals("menu_page")) {

		}
		else if(request.getParameter("from").contentEquals("companyinfo_page")) {
			if(request.getParameter("country").trim().isEmpty()) {
				model.addAttribute("errorMsg", "Please fill in all the blanks on this form" );

			}
			else if(request.getParameter("province").trim().isEmpty()) {
				model.addAttribute("errorMsg", "Please fill in all the blanks on this form" );

			}
			else if(request.getParameter("locality").trim().isEmpty()) {
				model.addAttribute("errorMsg", "Please fill in all the blanks on this form" );

			}
			else if(request.getParameter("organization").trim().isEmpty()) {
				model.addAttribute("errorMsg", "Please fill in all the blanks on this form" );

			}
			else if(request.getParameter("organizationUnit").trim().isEmpty()) {
				model.addAttribute("errorMsg", "Please fill in all the blanks on this form" );

			}
			else if(request.getParameter("domain").trim().isEmpty()) {
				model.addAttribute("errorMsg", "Please fill in all the blanks on this form" );

			}
			else if(request.getParameter("email").trim().isEmpty()) {
				model.addAttribute("errorMsg", "Please fill in all the blanks on this form" );

			}
			else if(request.getParameter("epcisAddress").trim().isEmpty()) {
				model.addAttribute("errorMsg", "Please fill in all the blanks on this form" );

			}
			else if(request.getParameter("street").trim().isEmpty()) {
				model.addAttribute("errorMsg", "Please fill in all the blanks on this form" );

			}
			else if(request.getParameter("postalCode").trim().isEmpty()) {
				model.addAttribute("errorMsg", "Please fill in all the blanks on this form" );

			}
			else if(request.getParameter("addressId").trim().isEmpty()) {
				model.addAttribute("errorMsg", "Please fill in all the blanks on this form" );

			}
			else {
				companyManager.Insert_CompanyInfo(
				    			request.getParameter("country"),
				    			request.getParameter("province"),
				    			request.getParameter("locality"),
				    			request.getParameter("organization"),
				    			request.getParameter("organizationUnit"),
				    			request.getParameter("domain"),
				    			request.getParameter("email"),
				    			request.getParameter("epcisAddress"),
				    			request.getParameter("street"),
				    			request.getParameter("postalCode"),
				    			request.getParameter("addressId")
				    			);
				model.addAttribute("errorMsg", "Modification Complete!" );
			}
		}
		InfoType_Company company = companyManager.getCompanyInfo();
		model.addAttribute("company", company);
		return "redirect:/company_info";
	}
	
}
