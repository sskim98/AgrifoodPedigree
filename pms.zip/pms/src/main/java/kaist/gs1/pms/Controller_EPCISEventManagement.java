package kaist.gs1.pms;

import java.net.InetAddress;
import java.security.Principal;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import javax.net.ssl.X509TrustManager;
import javax.security.cert.X509Certificate;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import kaist.gs1.pms.MyShellCommand;
import kaist.gs1.pms.InfoType_User;
import kaist.gs1.pms.RepositoryDao_User;

/**
 * Handles requests for the application home page.
 */
@Controller
public class Controller_EPCISEventManagement {
	@Autowired
	ServletContext servletContext;
	@Autowired
	Manager_CompanyInfo companyManager;
	@Autowired
	Manager_EPCISEvent epcisEventManager;
	@Autowired
	Manager_PedigreeGenerator pedigreeGenerator;
	@Autowired
	Manager_PedigreeInfo pedigreeManager;
	@Autowired
	Manager_PartnerInfo partnerManager;
	
	private static final Logger logger = LoggerFactory.getLogger(Controller_Home.class);
	String ErrorMsg = "";
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/epcisEvent")
	public String epcisEvent(HttpServletRequest request, ModelMap model, Principal principal, RedirectAttributes redirectAttr) {
		model.addAttribute("homeUrl", servletContext.getContextPath());
		Iterable<InfoType_EPCISEvent> events= epcisEventManager.getAllEvent();
		model.addAttribute("events", events);
		Iterable<InfoType_Pedigree> pedigrees= pedigreeManager.Get_PedigreeList();
		model.addAttribute("pedigrees", pedigrees);
		model.addAttribute("errorMsg", ErrorMsg );
		ErrorMsg = "";
		return "epcisEvent";
		
	}
	
	@RequestMapping(value = "/getEPCISEvent", method = RequestMethod.POST)
	public String getEPCISEvent(HttpServletRequest request, ModelMap model, Principal principal, RedirectAttributes redirectAttr) {
		model.addAttribute("homeUrl", servletContext.getContextPath());
		//model.addAttribute("initialPedigree", request.getParameter("xml"));
		
		InfoType_Company company = companyManager.getCompanyInfo();
		InfoType_EPCISEvent event = epcisEventManager.getMasterData();
		String queryString = company.getEpcisAddress()+"/Service/Poll/SimpleEventQuery?";
		if(event != null) {
			 queryString = queryString + "GE_recordTime=" + event.getLastEventRecordTime();
		}
		epcisEventManager.fetchEPCISEvents(queryString);
		return "redirect:epcisEvent";
		
	}
	
	@RequestMapping(value = "/handleEvent", method = RequestMethod.POST)
	public String handleEvent(HttpServletRequest request, ModelMap model, Principal principal, RedirectAttributes redirectAttr) {
		model.addAttribute("homeUrl", servletContext.getContextPath());
		//model.addAttribute("initialPedigree", request.getParameter("xml"));
		
		
		epcisEventManager.handleEvents();
		return "redirect:epcisEvent";
		
	}
	
	
}
