package kaist.gs1.pms;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.InetAddress;
import java.security.Principal;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import javax.net.ssl.X509TrustManager;
import javax.security.cert.X509Certificate;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import kaist.gs1.pms.MyShellCommand;
import kaist.gs1.pms.InfoType_User;
import kaist.gs1.pms.RepositoryDao_User;

/**
 * Handles requests for the application home page.
 */
@Controller
public class Controller_Home {
	@Autowired
	ServletContext servletContext;
	@Autowired
	Manager_UserInfo userManager;
	@Autowired
	private RepositoryDao_User userRepositoryDao;
	@Autowired
	Manager_Certificate certManager;
	
	private static final Logger logger = LoggerFactory.getLogger(Controller_Home.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	/*
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	*/

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String defaultPage(ModelMap model) {
		model.addAttribute("homeUrl", servletContext.getContextPath() );
		return "menu";
	}
	
	@RequestMapping(value = "/menu", method = RequestMethod.GET)
	public String menu(ModelMap model) {
		model.addAttribute("homeUrl", servletContext.getContextPath());
		return "menu";
	}

	
	
	public void commandTest(){
		MyShellCommand obj = new MyShellCommand();

		String domainName = "google.com";
		String command = "ping " + domainName;
		
		String output = obj.executeCommand(command);

		//System.out.println(output);
		
		List<String> list = obj.getIpAddress(output);

		if (list.size() > 0) {
			System.out.printf("%s has address : %n", domainName);
			for (String ip : list) {
				System.out.println(ip);
			}
		} else {
			System.out.printf("%s has NO address. %n", domainName);
		}
	}
	
	@RequestMapping(value = "/certificate", method = RequestMethod.GET)
	public String certificate(ModelMap model, HttpServletRequest request) {		
		model.addAttribute("homeUrl", servletContext.getContextPath() );
		InfoType_Certificate certAndPrivateKey = certManager.getPMSCertificateAndPrivateKey();
		model.addAttribute("privateKey", certAndPrivateKey.getPrivateKey().replaceAll("\r?\n", "<br>"));
		model.addAttribute("certificate", certAndPrivateKey.getCertificate().replaceAll("\r?\n", "<br>"));
		return "certificate_registration";
	}
	@RequestMapping(value = "/uploadCertificate", method = RequestMethod.POST)
	public String uploadCertificate(ModelMap model, MultipartHttpServletRequest request) {		
		model.addAttribute("homeUrl", servletContext.getContextPath() );
		Iterator<String> iterator = request.getFileNames();
	    MultipartFile multipartFile = null;
	    InfoType_Certificate certificateInfo = new InfoType_Certificate("", "");
	    
	    while(iterator.hasNext()){
	        multipartFile = request.getFile(iterator.next());
	        String fileContent = null;
	        try {
	        	fileContent = new String(multipartFile.getBytes());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        if(multipartFile.isEmpty() == false){
	        	if(fileContent.contains("RSA PRIVATE KEY" )) {
	        		certificateInfo.setPrivateKey(fileContent);
	        	}
	        	else if(fileContent.contains("BEGIN CERTIFICATE" )) {
	        		certificateInfo.setCertificate(fileContent);
	        	}
	            System.out.printf("------------- file start -------------\n");
	            System.out.printf("name : "+multipartFile.getName()+"\n");
	            System.out.printf("filename : "+multipartFile.getOriginalFilename()+"\n");
	            System.out.printf("size : "+multipartFile.getSize()+"\n");
	            System.out.printf("file : "+fileContent+"\n");
	            System.out.printf("-------------- file end --------------\n");
	        }
	    }
	    certManager.saveCertificateInfo(certificateInfo);
		return "redirect:/certificate";
	}
	
	@RequestMapping(value = "/cert", method = RequestMethod.POST)
	public String cert(ModelMap model, HttpServletRequest request) {
		model.addAttribute("homeUrl", servletContext.getContextPath() );
		certManager.test();
		
		return "index";
	}
}
