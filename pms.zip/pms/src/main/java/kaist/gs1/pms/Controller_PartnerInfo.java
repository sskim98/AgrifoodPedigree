package kaist.gs1.pms;

import java.net.InetAddress;
import java.security.Principal;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import javax.net.ssl.X509TrustManager;
import javax.security.cert.X509Certificate;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import kaist.gs1.pms.MyShellCommand;
import kaist.gs1.pms.InfoType_User;
import kaist.gs1.pms.RepositoryDao_User;

/**
 * Handles requests for the application home page.
 */
@Controller
public class Controller_PartnerInfo {
	@Autowired
	ServletContext servletContext;
	@Autowired
	Manager_PartnerInfo partnerManager;
	
	private static final Logger logger = LoggerFactory.getLogger(Controller_Home.class);
	String ErrorMsg = "";
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/change_partner", method = RequestMethod.POST)
	public String change_partner(HttpServletRequest request, ModelMap model, Principal principal) {
		
		model.addAttribute("homeUrl", servletContext.getContextPath());
		//if(request.getParameter("from").contentEquals("partnerlist_page")){
			if(request.getParameter("name").trim().isEmpty()) {
				ErrorMsg = "Please fill in all the blanks on this form";
			}
			else if(request.getParameter("street1").trim().isEmpty()) {
				ErrorMsg = "Please fill in all the blanks on this form";
			}
			else if(request.getParameter("street2").trim().isEmpty()) {
				ErrorMsg = "Please fill in all the blanks on this form";
			}
			else if(request.getParameter("city").trim().isEmpty()) {
				ErrorMsg = "Please fill in all the blanks on this form";
			}
			else if(request.getParameter("state").trim().isEmpty()) {
				ErrorMsg = "Please fill in all the blanks on this form";
			}
			else if(request.getParameter("postalCode").trim().isEmpty()) {
				ErrorMsg = "Please fill in all the blanks on this form";
			}
			else if(request.getParameter("country").trim().isEmpty()) {
				ErrorMsg = "Please fill in all the blanks on this form";
			}
			else if(request.getParameter("addressId").trim().isEmpty()) {
				ErrorMsg = "Please fill in all the blanks on this form";
			}
			else if(request.getParameter("pmsAddress").trim().isEmpty()) {
				ErrorMsg = "Please fill in all the blanks on this form";
			}
			else if(request.getParameter("alias").trim().isEmpty()) {
				ErrorMsg = "Please fill in all the blanks on this form";
			}
			else {
				String action = request.getParameter("action");
				if(action.equals("Add")) {
					boolean result = partnerManager.Insert_PartnerInfo(
							request.getParameter("name"),
							request.getParameter("street1"),
							request.getParameter("street2"),
							request.getParameter("city"),
							request.getParameter("state"),
							request.getParameter("postalCode"),
							request.getParameter("country"),
							request.getParameter("addressId"),
							request.getParameter("pmsAddress"),
							request.getParameter("alias")
							);
					if(result == false) {
						ErrorMsg = "Duplicated Partner's PMS Address";
					}
				}
				else if(action.equals("Change")) {
					boolean result = partnerManager.Update_PartnerInfo(
							request.getParameter("index"),
							request.getParameter("name"),
							request.getParameter("street1"),
							request.getParameter("street2"),
							request.getParameter("city"),
							request.getParameter("state"),
							request.getParameter("postalCode"),
							request.getParameter("country"),
							request.getParameter("addressId"),
							request.getParameter("pmsAddress"),
							request.getParameter("alias")
							);
					if(result == false) {
						ErrorMsg = "Can't Find Partner's PMS Address";
					}
				}
				else if(action.equals("Delete")) {
					boolean result = partnerManager.Delete_PartnerInfo(request.getParameter("index"));
					if(result == false) {
						ErrorMsg = "Can't Find Partner's PMS Address";
					}
				}
			}
			Iterable<InfoType_Partner> partners= partnerManager.getPartnerList();
			model.addAttribute("partners", partners);
			return "redirect:/partnerlist";
		//}
	}
	
	@RequestMapping(value = "/partnerlist", method = RequestMethod.GET)
	public String partnerlist(HttpServletRequest request, ModelMap model, Principal principal) {
		
		model.addAttribute("homeUrl", servletContext.getContextPath());
		
		Iterable<InfoType_Partner> partners= partnerManager.getPartnerList();
		model.addAttribute("partners", partners);
		model.addAttribute("errorMsg", ErrorMsg );
		ErrorMsg = "";
		return "partnerlist";

	}
}
