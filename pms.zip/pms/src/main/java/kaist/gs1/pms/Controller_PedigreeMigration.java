package kaist.gs1.pms;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.security.Principal;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import javax.net.ssl.X509TrustManager;
import javax.security.cert.X509Certificate;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import kaist.gs1.pms.MyShellCommand;
import kaist.gs1.pms.InfoType_User;
import kaist.gs1.pms.RepositoryDao_User;

/**
 * Handles requests for the application home page.
 */
@Controller
public class Controller_PedigreeMigration {
	@Autowired
	ServletContext servletContext;
	@Autowired
	Manager_PedigreeGenerator pedigreeGenerator;
	@Autowired
	Manager_PedigreeInfo pedigreeManager;
	@Autowired
	Manager_PedigreeExporter exportManager;
	@Autowired
	Manager_PedigreeImporter importManager;
	@Autowired
	Manager_PartnerInfo partnerManager;
	
	private static final Logger logger = LoggerFactory.getLogger(Controller_Home.class);
	String ErrorMsg = "";
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/import", method = RequestMethod.POST)
	public @ResponseBody String ssltest(ModelMap model, HttpServletRequest request) {
		X509Certificate[] certs = (X509Certificate[]) request.getAttribute("javax.servlet.request.X509Certificate");
        if (certs != null) {
            for (int i = 0; i < certs.length; i++) {
                System.out.println("Client Certificate [" + i + "] = "
                        + certs[i].toString());
            }
        }
		
        //commandTest();
        //model.addAttribute("xml", request.getParameter("pedigree") );
        System.out.println("request content length:" + request.getContentLength() );
        BufferedReader in;
        StringBuffer buffer = new StringBuffer();
        String inputLine;
		try {
			in = new BufferedReader(new InputStreamReader(request.getInputStream()));
			
			while ((inputLine = in.readLine()) != null) {
				buffer.append(inputLine);
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        System.out.println("request content :" + buffer);
        //String pedigree = request.getParameter("pedigree");
        String importPedigree = buffer.toString();
        //System.out.println(importPedigree);
        //System.out.println(exportManager.Find_Pedigree("01880001000025321344135").getXml());
        String response_str = "data stored";
        boolean validity_result = importManager.checkPedigree(importPedigree);
        if(validity_result) {
        	importManager.Import_Pedigree(importPedigree);
        	return response_str; 
        }
        else {
        	return "validity failure";
        }
	}
	
	@RequestMapping(value = "/export", method = RequestMethod.POST)
	public String export(ModelMap model, HttpServletRequest request) {
		model.addAttribute("homeUrl", servletContext.getContextPath() );
		if(partnerManager.selectPartnerInfo(request.getParameter("select")) != null) {
			exportManager.Export_Pedigree(request.getParameter("select"), request.getParameter("selectedShippedPedigreeSgtin"));
		}
		
		
		return "redirect:/pedigreelist";
	}
	
}
