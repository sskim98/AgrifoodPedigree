package kaist.gs1.pms;

import java.awt.Menu;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.Serializable;
import java.net.InetAddress;
import java.security.Principal;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import javax.net.ssl.X509TrustManager;
import javax.security.cert.X509Certificate;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import kaist.gs1.pms.MyShellCommand;
import kaist.gs1.pms.InfoType_User;
import kaist.gs1.pms.RepositoryDao_User;

/**
 * Handles requests for the application home page.
 */
@Controller
public class Controller_Search {
	@Autowired
	ServletContext servletContext;
	@Autowired
	Manager_Search searchManager;
	
	private static final Logger logger = LoggerFactory.getLogger(Controller_Home.class);


	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public String search(ModelMap model, HttpServletRequest request) {
		
		String sgtin = request.getParameter("sgtin");
		InfoType_Pedigree pedigree = searchManager.Find_Pedigree(sgtin);
		if(pedigree != null) {
			ArrayList<InfoType_Trace> path = searchManager.Get_Pedigree_TraceInfo(pedigree.getXml());

			model.addAttribute("searchResult", pedigree );
			model.addAttribute("traceInfo", path);
			System.out.println("request id:" + sgtin );
			return "searchResult";
		}
		else {
			return "searchFailure";
		}
	}
	
}
