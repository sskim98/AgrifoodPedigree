package kaist.gs1.pms;

import java.net.InetAddress;
import java.security.Principal;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import javax.net.ssl.X509TrustManager;
import javax.security.cert.X509Certificate;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kaist.gs1.pms.MyShellCommand;
import kaist.gs1.pms.InfoType_User;
import kaist.gs1.pms.RepositoryDao_User;

/**
 * Handles requests for the application home page.
 */
@Controller
public class Controller_UserInfo {
	@Autowired
	ServletContext servletContext;
	@Autowired
	Manager_UserInfo userManager;
	
	private static final Logger logger = LoggerFactory.getLogger(Controller_Home.class);
	String ErrorMsg = "";
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/user_info", method = RequestMethod.GET)
	public String user_info(HttpServletRequest request, ModelMap model, Principal principal) {
		model.addAttribute("homeUrl", servletContext.getContextPath());
		
			InfoType_User user = userManager.selectUserInfo(principal.getName());
			model.addAttribute("user", user);
			model.addAttribute("errorMsg", ErrorMsg );
			ErrorMsg = "";
			return "user_info";
		
	}
	
	@RequestMapping(value = "/change_user", method = RequestMethod.POST)
	public String change_info(HttpServletRequest request, ModelMap model, Principal principal) {
		//model.addAttribute("homeUrl", servletContext.getContextPath() );
		if(request.getParameter("from").contentEquals("userinfo_page")) {
			if(request.getParameter("userid").trim().isEmpty()) {
				ErrorMsg = "Please fill in all the blanks on this form";
			}
			else if(request.getParameter("password").trim().isEmpty()) {
				ErrorMsg = "Please fill in all the blanks on this form";
			}
			else if(request.getParameter("username").trim().isEmpty()) {
				ErrorMsg = "Please fill in all the blanks on this form";
			}
			else if(request.getParameter("department").trim().isEmpty()) {
				ErrorMsg = "Please fill in all the blanks on this form";
			}
			else if(request.getParameter("telephone").trim().isEmpty()) {
				ErrorMsg = "Please fill in all the blanks on this form";
			}
			else if(request.getParameter("email").trim().isEmpty()) {
				ErrorMsg = "Please fill in all the blanks on this form";
			}
			else {
				userManager.Update_UserInfo(
				    			request.getParameter("userid"),
				    			request.getParameter("password"),
				    			request.getParameter("username"),
				    			request.getParameter("department"),
				    			request.getParameter("telephone"),
				    			request.getParameter("email"),
				    			request.getParameter("authorities"),
				    			request.getParameter("index")
				    			);
				InfoType_User user = userManager.selectUserInfo(principal.getName());
				model.addAttribute("user", user);
			}
		}
		
		return "redirect:/user_info";
	}
	
	@RequestMapping(value = "/userlist", method = RequestMethod.GET)
	public String userlist(HttpServletRequest request, ModelMap model, Principal principal) {
		model.addAttribute("homeUrl", servletContext.getContextPath());
		Iterable<InfoType_User> users= userManager.getUserList();
		model.addAttribute("users", users);
		model.addAttribute("errorMsg", ErrorMsg );
		ErrorMsg = "";
		return "userlist";
		
	}
	
	@RequestMapping(value = "/change_list", method = RequestMethod.POST)
	public String change_user(HttpServletRequest request, ModelMap model, Principal principal) {
		//model.addAttribute("homeUrl", servletContext.getContextPath());
		if(request.getParameter("from").contentEquals("userlist_page")){
			if(request.getParameter("userid").trim().isEmpty()) {
				ErrorMsg = "Please fill in all the blanks on this form";
			}
			else if(request.getParameter("password").trim().isEmpty()) {
				ErrorMsg = "Please fill in all the blanks on this form";
			}
			else if(request.getParameter("username").trim().isEmpty()) {
				ErrorMsg = "Please fill in all the blanks on this form";
			}
			else if(request.getParameter("department").trim().isEmpty()) {
				ErrorMsg = "Please fill in all the blanks on this form";
			}
			else if(request.getParameter("telephone").trim().isEmpty()) {
				ErrorMsg = "Please fill in all the blanks on this form";
			}
			else if(request.getParameter("email").trim().isEmpty()) {
				ErrorMsg = "Please fill in all the blanks on this form";
			}
			else {
				String action = request.getParameter("action");
				if(action.equals("Add")) {
					boolean result = userManager.Insert_UserInfo(
							request.getParameter("userid"),
			    			request.getParameter("password"),
			    			request.getParameter("username"),
			    			request.getParameter("department"),
			    			request.getParameter("telephone"),
			    			request.getParameter("email"),
			    			request.getParameter("authorities")
							);
					if(result == false) {
						ErrorMsg =  "Duplicated User ID";
					}
				}
				else if(action.equals("Change")) {
					boolean result = userManager.Update_UserInfo(
							request.getParameter("userid"),
			    			request.getParameter("password"),
			    			request.getParameter("username"),
			    			request.getParameter("department"),
			    			request.getParameter("telephone"),
			    			request.getParameter("email"),
			    			request.getParameter("authorities"),
			    			request.getParameter("index")
							);
					if(result == false) {
						ErrorMsg = "Can't Find User ID";
					}
				}
				else if(action.equals("Delete")) {
					boolean result = userManager.Delete_UserInfo(request.getParameter("index"));
					if(result == false) {
						ErrorMsg = "Can't Find User ID";
					}
				}
			}
		}
		return "redirect:/userlist";
	}
}
