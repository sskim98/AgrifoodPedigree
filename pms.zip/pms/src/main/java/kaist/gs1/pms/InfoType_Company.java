package kaist.gs1.pms;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;


@Document(collection="CompanyInfo") 	 	
public class InfoType_Company {
	//private String _id;
	private String street;
	private String country;
	private String province;
	private String locality;
	private String name;
	private String department;
	private String postalCode;
	@Id
	private String domain;
	private String email;
	private String epcisAddress;
	private String addressId;

	public InfoType_Company(String country, String province, String locality, String name, String department, String domain, String email, String epcisAddress, String street, String postalCode, String addressId) {
		this.country = country;
		this.province = province;
		this.locality = locality;
		this.name = name;
		this.department = department;
		this.domain = domain;
		this.email = email;
		this.epcisAddress = epcisAddress;
		this.street = street;
		this.postalCode = postalCode;
		this.addressId = addressId;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getLocality() {
		return locality;
	}

	public void setLocality(String locality) {
		this.locality = locality;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEpcisAddress() {
		return epcisAddress;
	}

	public void setEpcisAddress(String epcisAddress) {
		this.epcisAddress = epcisAddress;
	}

	public String getAddressId() {
		return addressId;
	}

	public void setAddressId(String addressId) {
		this.addressId = addressId;
	}

	
}
