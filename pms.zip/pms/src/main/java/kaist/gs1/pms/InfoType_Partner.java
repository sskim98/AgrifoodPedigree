package kaist.gs1.pms;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;


@Document(collection="PartnerInfo") 	 	
public class InfoType_Partner {
	
	private String name;
	private String street1;
	private String street2;
	private String city;
	private String state;
	private String postalCode;
	private String country;
	private String addressId;
	@Id
	private String pmsAddress;
	private String alias;


	public InfoType_Partner(String name, String street1, String street2, String city, String state, String postalCode, String country, String addressId, String pmsAddress, String alias) {
		this.name = name;
		this.street1 =  street1;
		this.street2 = street2;
		this.city =  city;
		this.state = state;
		this.postalCode =  postalCode;
		this.country = country;
		this.addressId =  addressId;
		this.pmsAddress =  pmsAddress;
		this.alias =  alias;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getStreet1() {
		return street1;
	}


	public void setStreet1(String street1) {
		this.street1 = street1;
	}


	public String getStreet2() {
		return street2;
	}


	public void setStreet2(String street2) {
		this.street2 = street2;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getPostalCode() {
		return postalCode;
	}


	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public String getAddressId() {
		return addressId;
	}


	public void setAddressId(String addressId) {
		this.addressId = addressId;
	}


	public String getPmsAddress() {
		return pmsAddress;
	}


	public void setPmsAddress(String pmsAddress) {
		this.pmsAddress = pmsAddress;
	}


	public String getAlias() {
		return alias;
	}


	public void setAlias(String alias) {
		this.alias = alias;
	}

	
}
