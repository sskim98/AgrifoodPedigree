package kaist.gs1.pms;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;


@Document(collection="PedigreeInfo") 	 	
public class InfoType_Pedigree {
	
	@Id
	private String _id;
	private String sgtin;
	private String type;
	private String modifiedTime;
	private String xml;

	public InfoType_Pedigree(String _id, String sgtin, String type, String modifiedTime, String xml) {
		this._id = _id;
		this.sgtin = sgtin;
		this.type = type;
		this.modifiedTime = modifiedTime;
		this.xml = xml;
	}

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

	public String getSgtin() {
		return sgtin;
	}

	public void setSgtin(String sgtin) {
		this.sgtin = sgtin;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getModifiedTime() {
		return modifiedTime;
	}

	public void setModifiedTime(String modifiedTime) {
		this.modifiedTime = modifiedTime;
	}

	public String getXml() {
		return xml;
	}

	public void setXml(String xml) {
		this.xml = xml;
	}


}
