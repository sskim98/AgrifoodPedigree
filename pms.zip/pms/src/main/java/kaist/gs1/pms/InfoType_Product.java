package kaist.gs1.pms;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;


@Document(collection="ProductInfo") 	 	
public class InfoType_Product {
	@Id
	private String _id;
	private String name;
	private String manufacturer;
	private String productCode;
	private String productCodeType;
	private String dosageForm;
	private String strength;
	private String containerSize;
	private String lot;
	private String expirationDate;

	public InfoType_Product(String name, String manufacturer, String productCode, String productCodeType, String dosageForm, String strength, String containerSize, String lot, String expirationDate) {
		this._id = productCode;
		this.name = name;
		this.manufacturer =  manufacturer;
		this.productCode = productCode;
		this.productCodeType =  productCodeType;
		this.dosageForm = dosageForm;
		this.strength =  strength;
		this.containerSize = containerSize;
		this.lot =  lot;
		this.expirationDate =  expirationDate;
	}

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getProductCodeType() {
		return productCodeType;
	}

	public void setProductCodeType(String productCodeType) {
		this.productCodeType = productCodeType;
	}

	public String getDosageForm() {
		return dosageForm;
	}

	public void setDosageForm(String dosageForm) {
		this.dosageForm = dosageForm;
	}

	public String getStrength() {
		return strength;
	}

	public void setStrength(String strength) {
		this.strength = strength;
	}

	public String getContainerSize() {
		return containerSize;
	}

	public void setContainerSize(String containerSize) {
		this.containerSize = containerSize;
	}

	public String getLot() {
		return lot;
	}

	public void setLot(String lot) {
		this.lot = lot;
	}

	public String getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}

	
}
