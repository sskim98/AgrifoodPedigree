package kaist.gs1.pms;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import kaist.gs1.pms.RepositoryDao_User;

@Component
public class Manager_CompanyInfo extends BaseManager_Info {
    private static final Logger logger = Logger.getLogger(BaseManager_Info.class);
    
    public boolean Insert_CompanyInfo(String country, String province, String locality, String name, String department, String domain, String email, String epcisAddress, String street, String postalCode, String addressId) {
    	removeAllCompanyInfo();
    	InfoType_Company company = new InfoType_Company( country, province, locality, name, department, domain, email, epcisAddress, street, postalCode, addressId);
    	saveCompanyInfo(company);
        return true;
    }
    
}