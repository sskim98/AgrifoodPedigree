package kaist.gs1.pms;

import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;

import javax.annotation.Resource;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import org.w3c.dom.*;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import javax.xml.crypto.AlgorithmMethod;
import javax.xml.crypto.KeySelector;
import javax.xml.crypto.KeySelectorException;
import javax.xml.crypto.KeySelectorResult;
import javax.xml.crypto.MarshalException;
import javax.xml.crypto.XMLCryptoContext;
import javax.xml.crypto.XMLStructure;
import javax.xml.crypto.dsig.CanonicalizationMethod;
import javax.xml.crypto.dsig.DigestMethod;
import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.SignatureMethod;
import javax.xml.crypto.dsig.SignedInfo;
import javax.xml.crypto.dsig.Transform;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureException;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMSignContext;
import javax.xml.crypto.dsig.dom.DOMValidateContext;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;
import javax.xml.crypto.dsig.keyinfo.KeyInfoFactory;
import javax.xml.crypto.dsig.keyinfo.X509Data;
import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;
import javax.xml.crypto.dsig.spec.TransformParameterSpec;
import javax.xml.parsers.*;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.InvalidAlgorithmParameterException;
import java.security.Key;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.Principal;
import java.security.PublicKey;
import java.security.UnrecoverableEntryException;
import java.security.UnrecoverableKeyException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.time.ZoneOffset;

import kaist.gs1.pms.RepositoryDao_User;

@Component
public class Manager_EPCISEvent extends BaseManager_EPCISEvent {
    private static final Logger logger = Logger.getLogger(BaseManager_Info.class);
    @Autowired
    private Manager_PedigreeGenerator pedigreeGenerator;
    
    public Iterable<InfoType_EPCISEvent> getEPCISEvents() {
    	Iterable<InfoType_EPCISEvent> events = getAllEvent();
        return events;
    }
    
    public boolean fetchEPCISEvents(String urlString) {
    	String response = "";
		try {
			//authmgr.getHttps("https://itc.kaist.ac.kr/xe/");
			response = getHttp(urlString);
		} catch (KeyManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(response != "") {
			response = response.replaceAll(">\\s+", ">");
			System.out.println(response);
			Document eventDocument = buildDocumentfromString(response);
			NodeList eventList = eventDocument.getElementsByTagName("ObjectEvent");
			if(eventList.getLength() > 0) {
				for(int i=0; i<eventList.getLength(); i++) {
					String type = "event";
					String lastEventRecordTime = "";
					String eventTime = "";
					String recordTime = "";
					String eventTimeZoneOffset = "";
					String epc = "";
					String bizStep = "";
					String action = "";
					
					
					Element element = (Element)(eventList.item(i));
					if(element.getElementsByTagName("eventTime").getLength() > 0) {
						eventTime = element.getElementsByTagName("eventTime").item(0).getTextContent();
					}
					if(element.getElementsByTagName("recordTime").getLength() > 0) {
						recordTime = element.getElementsByTagName("recordTime").item(0).getTextContent();
					}
					if(element.getElementsByTagName("eventTimeZoneOffset").getLength() > 0) {
						eventTimeZoneOffset = element.getElementsByTagName("eventTimeZoneOffset").item(0).getTextContent();
					}
					if(element.getElementsByTagName("bizStep").getLength() > 0) {
						bizStep = element.getElementsByTagName("bizStep").item(0).getTextContent();
					}
					if(element.getElementsByTagName("action").getLength() > 0) {
						action = element.getElementsByTagName("action").item(0).getTextContent();
					}
					String eventXml = getStringFromElement(element);
					if(element.getElementsByTagName("epc").getLength() > 0) {
						for(int j=0; j<element.getElementsByTagName("epc").getLength(); j++) {
							epc = element.getElementsByTagName("epc").item(j).getTextContent();
							InfoType_EPCISEvent event = new InfoType_EPCISEvent(type, lastEventRecordTime, eventTime, recordTime, epc, bizStep, action, eventXml);
							storeEvent(event);
							updateLastEventRecordTime(recordTime, eventTimeZoneOffset);
						}
					}
				}
			}
		}
		
		return true;
    }
    
    public String getHttp(String urlString) throws IOException, NoSuchAlgorithmException, KeyManagementException {
		// Get HTTP URL connection
		URL url = new URL(urlString);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("GET");
		
		// Connect to host
		conn.connect();
		//conn.setInstanceFollowRedirects(true);

		if (conn.getResponseCode() == 200) {
			// Print response from host
			InputStream in = conn.getInputStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(in));
			StringBuffer response = new StringBuffer();
			String line = null;
			while ((line = reader.readLine()) != null) {
				response.append(line);
			}
			reader.close();
	    	System.out.println(response.toString());
			return response.toString();
		} else {
			conn.disconnect();
			return "";
		}
	}

    public void handleEvents() {
    	Iterable<InfoType_EPCISEvent> events = selectEventByBizStep("urn:epcglobal:cbv:bizstep:commissioning");;
    	Iterator<InfoType_EPCISEvent> event = events.iterator();
    	InfoType_EPCISEvent element = null;
    	while(event.hasNext()) { 
    		element = event.next();
    		pedigreeGenerator.Generate_InitialPedigree(element.getEpc(), element.getEventXml());
    		removeEvent(element);
    	}
    	
    	events = selectEventByBizStep("urn:epcglobal:cbv:bizstep:shipping");
    	event = events.iterator();
    	while(event.hasNext()) {
    		element = event.next();
    		pedigreeGenerator.Generate_ShippedPedigree(element.getEpc());
    		removeEvent(element);
    	}
    	
    	events = selectEventByBizStep("urn:epcglobal:cbv:bizstep:receiving");
    	event = events.iterator();
    	while(event.hasNext()) {
    		element = event.next();
    		pedigreeGenerator.Generate_ReceivedPedigree(element.getEpc());
    		removeEvent(element);
    	}
    }
    
    public void updateLastEventRecordTime(String newRecordTime, String zone) {
    	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");

    	formatter.setTimeZone(TimeZone.getTimeZone("GMT"+zone));
        Date date;
		try {
			date = formatter.parse(newRecordTime.replaceAll("Z", zone));
			InfoType_EPCISEvent masterEvent = getMasterData();
	        date.setTime(date.getTime()+1);
	        formatter.format(date);
	        SimpleDateFormat form = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
	        form.setTimeZone(TimeZone.getTimeZone("GMT"+zone));
	        if(masterEvent == null) {
	        	masterEvent = new InfoType_EPCISEvent("master", form.format(date), "-", "-", "-", "-", "-", "-");
	        }
	        else {
	        	Date lastEventRecordTime = formatter.parse(masterEvent.getLastEventRecordTime());
	        	if( lastEventRecordTime.getTime() < date.getTime() ) {
	        		masterEvent.setLastEventRecordTime(form.format(date));
	        	}
	        }
	        storeEvent(masterEvent);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}