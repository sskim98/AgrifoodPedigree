package kaist.gs1.pms;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import kaist.gs1.pms.RepositoryDao_User;

@Component
public class Manager_PartnerInfo extends BaseManager_Info {
    private static final Logger logger = Logger.getLogger(BaseManager_Info.class);
    
    public boolean Insert_PartnerInfo(String name, String street1, String street2, String city, String state, String postalCode, String country, String addressId, String pmsAddress, String alias) {
    	InfoType_Partner partner = this.selectPartnerInfo(pmsAddress);
        if(partner == null) {
        	partner = new InfoType_Partner( name, street1, street2, city, state, postalCode, country, addressId, pmsAddress, alias);
        	savePartnerInfo(partner);
    	return true;
        }
        else {
        	return false;
        }
    }
    
    public boolean Update_PartnerInfo(String index, String name, String street1, String street2, String city, String state, String postalCode, String country, String addressId, String pmsAddress, String alias) {
    	InfoType_Partner partner = this.selectPartnerInfo(index);
        if(partner != null) {
        	removePartnerInfo(partner);
        	partner = new InfoType_Partner( name, street1, street2, city, state, postalCode, country, addressId, pmsAddress, alias);
        	savePartnerInfo(partner);
        	return true;
        }
        else {
        	return false;
        }
    }
    
    public boolean Delete_PartnerInfo(String address) {
    	InfoType_Partner partner = this.selectPartnerInfo(address);
    	if(partner != null) {
    		removePartnerInfo(partner);
    	}
		return true;
    }

}