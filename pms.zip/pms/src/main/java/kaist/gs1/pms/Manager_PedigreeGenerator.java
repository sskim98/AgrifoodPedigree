package kaist.gs1.pms;

import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import org.w3c.dom.*;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import javax.xml.crypto.AlgorithmMethod;
import javax.xml.crypto.KeySelector;
import javax.xml.crypto.KeySelectorException;
import javax.xml.crypto.KeySelectorResult;
import javax.xml.crypto.MarshalException;
import javax.xml.crypto.XMLCryptoContext;
import javax.xml.crypto.XMLStructure;
import javax.xml.crypto.dsig.CanonicalizationMethod;
import javax.xml.crypto.dsig.DigestMethod;
import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.SignatureMethod;
import javax.xml.crypto.dsig.SignedInfo;
import javax.xml.crypto.dsig.Transform;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureException;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMSignContext;
import javax.xml.crypto.dsig.dom.DOMValidateContext;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;
import javax.xml.crypto.dsig.keyinfo.KeyInfoFactory;
import javax.xml.crypto.dsig.keyinfo.X509Data;
import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;
import javax.xml.crypto.dsig.spec.TransformParameterSpec;
import javax.xml.parsers.*;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import java.io.*;
import java.security.InvalidAlgorithmParameterException;
import java.security.Key;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.UnrecoverableEntryException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import kaist.gs1.pms.RepositoryDao_User;

@Component
public class Manager_PedigreeGenerator extends BaseManager_Info {
    private static final Logger logger = Logger.getLogger(BaseManager_Info.class);
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

    public InfoType_Pedigree Find_Pedigree(String sgtin) {
    	InfoType_Pedigree pedigree = selectPedigree(sgtin);
        return pedigree;
    }
    
    public String Generate_InitialPedigree(String sgtin, String productName, String manufacturer, String productCode, String containerSize, String lot, String expirationDate, String quantity, String itemSerialNumber) {
    	if(sgtin.length() > 0) {
	    	InfoType_Pedigree previousPedigree = Find_Pedigree(sgtin);
	    	if(previousPedigree == null) {
	    		String[] array = sgtin.replaceAll(".*:", "").split("\\.");
	    		String gtin = array[0] + array[1];
	    		InfoType_Product product = selectProductInfo(gtin);
	    		
		    	initialPedigree initialPedigreeData = new initialPedigree(sgtin, productName, manufacturer, productCode, containerSize, lot, expirationDate, quantity, itemSerialNumber);
		    	Document doc_initial = buildDocumentfromObject(initialPedigreeData);
		    	String xml = getStringFromDocument(doc_initial);
		    	InfoType_Pedigree initialPedigree = new InfoType_Pedigree(sgtin , sgtin, "Initial", getCurrentTime(), xml); 
		    	boolean status = savePedigree(initialPedigree);
		    	return xml;
	    	}
	    	else {
	    		return "false";
	    	}
    	}
    	else {
    		return "false";
    	}
    }
    
    public String Generate_InitialPedigree(String sgtin, String eventXml) {
    	if(sgtin.length() > 0) {
	    	InfoType_Pedigree previousPedigree = Find_Pedigree(sgtin);
	    	if(previousPedigree == null) {
	    		String[] array = sgtin.replaceAll(".*:", "").split("\\.");
	    		String gtin = array[0] + array[1];
	    		InfoType_Product product = selectProductInfo(gtin);
	    		
		    	initialPedigree initialPedigreeData = new initialPedigree(sgtin, product, buildDocumentfromString(eventXml));
		    	//buildDocumentfromNestedObject(initialPedigreeData);
		    	Document doc_initial = buildDocumentfromObject(initialPedigreeData);
		    	String pedXml = getStringFromDocument(doc_initial);
		    	InfoType_Pedigree initialPedigree = new InfoType_Pedigree(sgtin , sgtin, "Initial", getCurrentTime(), pedXml); 
		    	boolean status = savePedigree(initialPedigree);
		    	return pedXml;
	    	}
	    	else {
	    		return "false";
	    	}
    	}
    	else {
    		return "false";
    	}
    }
    
    public String Generate_ShippedPedigree(String sgtin) {
    	InfoType_Pedigree previousPedigree = Find_Pedigree(sgtin);
    	if(previousPedigree != null) {
    		pedigree pedigree = new pedigree();
    		Document doc = buildDocumentfromObject(pedigree);
    		shippedPedigree shippedPedigreeData = new shippedPedigree(sgtin);
    		Document doc_shipped = buildDocumentfromObject(shippedPedigreeData);
    		Document doc_previous = buildDocumentfromString(previousPedigree.getXml());
    		doc_shipped.getDocumentElement().replaceChild(doc_shipped.adoptNode(doc_previous.getDocumentElement().cloneNode(true)), doc_shipped.getDocumentElement().getElementsByTagName("previousPedigree").item(0));
    		doc.getDocumentElement().appendChild(doc.adoptNode(doc_shipped.getDocumentElement().cloneNode(true)));
    		
    		String xml = signPedigree(doc, sgtin);
    		InfoType_Pedigree shippedPedigree = new InfoType_Pedigree(sgtin , sgtin, "Shipped", getCurrentTime(), xml); 
        	boolean status = savePedigree(shippedPedigree);
        	boolean validity = checkPedigree(shippedPedigree.getXml());
    		return xml;
    	}
    	else {
    		return "failure";
    	}
    }
    
    public String Generate_ReceivedPedigree(String sgtin) {
    	InfoType_Pedigree previousPedigree = Find_Pedigree(sgtin);
    	if(previousPedigree != null) {
    		if(previousPedigree.getType().contentEquals("Imported") ) {
	    		pedigree pedigree = new pedigree();
	    		Document doc = buildDocumentfromObject(pedigree);
	    		receivedPedigree receivedPedigreeData = new receivedPedigree(sgtin);
	    		Document doc_received = buildDocumentfromObject(receivedPedigreeData);
	    		Document doc_previous = buildDocumentfromString(previousPedigree.getXml());
	    		doc_received.getDocumentElement().replaceChild(doc_received.adoptNode(doc_previous.getDocumentElement().cloneNode(true)), doc_received.getDocumentElement().getElementsByTagName("previousPedigree").item(0));
	    		doc.getDocumentElement().appendChild(doc.adoptNode(doc_received.getDocumentElement().cloneNode(true)));
	    		String xml = signPedigree(doc, sgtin);
	    		InfoType_Pedigree receivedPedigree = new InfoType_Pedigree(sgtin , sgtin, "Received", getCurrentTime(), xml); 
	        	boolean status = savePedigree(receivedPedigree);
	        	boolean validity = checkPedigree(receivedPedigree.getXml());
	    		return xml;
    		}
    		else {
    			return "failure";
    		}
    	}
    	else {
    		return "failure";
    	}
    }
    
    


}