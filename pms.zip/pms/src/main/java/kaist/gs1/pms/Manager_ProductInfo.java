package kaist.gs1.pms;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import kaist.gs1.pms.RepositoryDao_User;

@Component
public class Manager_ProductInfo extends BaseManager_Info {
    private static final Logger logger = Logger.getLogger(BaseManager_Info.class);
   
    public boolean Insert_ProductInfo(String name, String manufacturer, String productCode, String productCodeType, String dosageForm, String strength, String containerSize, String lot, String expirationDate) {
    	InfoType_Product product = this.selectProductInfo(productCode);
        if(product == null) {
        	product = new InfoType_Product(name, manufacturer, productCode, productCodeType, dosageForm, strength, containerSize, lot, expirationDate);
        	saveProductInfo(product);
    	return true;
        }
        else {
        	return false;
        }
    }
    
    public boolean Update_ProductInfo(String name, String manufacturer, String productCode, String productCodeType, String dosageForm, String strength, String containerSize, String lot, String expirationDate) {
    	InfoType_Product product = this.selectProductInfo(productCode);
        if(product != null) {
        	removeProductInfo(product);
        	product = new InfoType_Product( name, manufacturer, productCode, productCodeType, dosageForm, strength, containerSize, lot, expirationDate);
        	saveProductInfo(product);
        	return true;
        }
        else {
        	return false;
        }
    }
    
    public boolean Delete_ProductInfo(String productCode) {
    	InfoType_Product product = this.selectProductInfo(productCode);
    	if(product != null) {
    		removeProductInfo(product);
    	}
		return true;
    }

}