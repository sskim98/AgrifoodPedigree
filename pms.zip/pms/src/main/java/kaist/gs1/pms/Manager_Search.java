package kaist.gs1.pms;

import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import org.apache.log4j.Logger;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import org.w3c.dom.*;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.dataformat.xml.ser.XmlSerializerProvider;

import javax.xml.crypto.AlgorithmMethod;
import javax.xml.crypto.KeySelector;
import javax.xml.crypto.KeySelectorException;
import javax.xml.crypto.KeySelectorResult;
import javax.xml.crypto.MarshalException;
import javax.xml.crypto.XMLCryptoContext;
import javax.xml.crypto.XMLStructure;
import javax.xml.crypto.dsig.CanonicalizationMethod;
import javax.xml.crypto.dsig.DigestMethod;
import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.SignatureMethod;
import javax.xml.crypto.dsig.SignedInfo;
import javax.xml.crypto.dsig.Transform;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureException;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMSignContext;
import javax.xml.crypto.dsig.dom.DOMValidateContext;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;
import javax.xml.crypto.dsig.keyinfo.KeyInfoFactory;
import javax.xml.crypto.dsig.keyinfo.X509Data;
import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;
import javax.xml.crypto.dsig.spec.TransformParameterSpec;
import javax.xml.parsers.*;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import java.io.*;
import java.net.URL;
import java.security.InvalidAlgorithmParameterException;
import java.security.Key;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.Principal;
import java.security.PublicKey;
import java.security.UnrecoverableEntryException;
import java.security.UnrecoverableKeyException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import kaist.gs1.pms.RepositoryDao_User;

@Component
public class Manager_Search extends BaseManager_Info {
    private static final Logger logger = Logger.getLogger(BaseManager_Info.class);
    
    public InfoType_Pedigree Find_Pedigree(String sgtin) {
    	InfoType_Pedigree pedigree = selectPedigree(sgtin);
        return pedigree;
    }
    
    public ArrayList<InfoType_Trace> Get_Pedigree_TraceInfo(String pedigree) {
    	ArrayList<InfoType_Trace> report = new ArrayList<InfoType_Trace>();
    	
    	String pedString = pedigree;
    	Document pedDoc = null;
    	while(pedString.length() > 0) {
    		pedDoc = buildDocumentfromString(pedString);
    		InfoType_Trace element = Analyze_Pedigree(getStringFromDocument(pedDoc));
    		if(element == null) {
    			break;
    		}
    		else {
    			report.add(element);
    			Node nextElements = pedDoc.getElementsByTagName("DataType_Pedigree").item(1);
    			pedString = getStringFromXmlNode(nextElements);
    		}
    	}
    	
    	Node initialPedigree = pedDoc.getElementsByTagName("DataType_InitialPedigree").item(0); 
    	if( initialPedigree != null) {
    		String company = pedDoc.getElementsByTagName("manufacturer").item(0).getFirstChild().getTextContent();
        	String gtin = pedDoc.getElementsByTagName("serialNumber").item(0).getFirstChild().getTextContent();
        	String type = initialPedigree.getNodeName();
        	//String eventTime = pedDoc.getElementsByTagName("eventTime").item(0).getFirstChild().getTextContent();
        	InfoType_Trace element = new InfoType_Trace(gtin, company, type, "", "-");
        	report.add(element);
    	}
    	
    	return report;
    }
    
    private String getStringFromXmlNode(Node node) {
    	if(node != null) {
    		TransformerFactory tFactory = TransformerFactory.newInstance();
    		Transformer transformer = null;
    		try {
    			transformer = tFactory.newTransformer();
    		} catch (TransformerConfigurationException e1) {
    			// TODO Auto-generated catch block
    			e1.printStackTrace();
    		}
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);

    		//Find the first child node - this could be done with xpath as well
    		DOMSource source = null;

    		if(node instanceof Element)
    		{
    			source = new DOMSource(node);
    		}

    		//Do the transformation and output
    		try {
    			transformer.transform(source, result);
    		} catch (TransformerException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
    		return sw.toString();
    	}
    	else {
    		return "";
    	}
    }

    public InfoType_Trace Analyze_Pedigree(String pedigree) {
    	Document pedDoc = buildDocumentfromString(pedigree);
    	String company = pedDoc.getElementsByTagName("manufacturer").item(0).getFirstChild().getTextContent();
    	String gtin = pedDoc.getElementsByTagName("serialNumber").item(0).getFirstChild().getTextContent();
    	String type = pedDoc.getFirstChild().getFirstChild().getNodeName();
    	//String eventTime = pedDoc.getElementsByTagName("eventTime").item(0).getFirstChild().getTextContent();
    	String validity = "TRUE";
    	if(pedDoc.getFirstChild().getNodeName() != "DataType_InitialPedigree") {
    		validity = String.valueOf(checkPedigree(pedigree));
    	}
    	InfoType_Trace element = new InfoType_Trace(gtin, company, type, "", validity);
    	return element;
    }
}