package kaist.gs1.pms;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import kaist.gs1.pms.RepositoryDao_User;

@Component
public class Manager_UserInfo extends BaseManager_Info {
    private static final Logger logger = Logger.getLogger(BaseManager_Info.class);
    
    public boolean Signup_UserInfo(String userid, String password, String username, String department, String telephone, String email) {
    	ArrayList<String> authList = new ArrayList<String>();
    	authList.add("ROLE_USER");
    	InfoType_User user = this.selectUserInfo(userid);
        if(user == null) {
        	user = new InfoType_User( null, userid, password, username, department, telephone, email, authList);
        	saveUserInfo(user);
        	return true;
        }
        else {
        	return false;
        }
        
    }
    
    public boolean Insert_UserInfo(String userid, String password, String username, String department, String telephone, String email, String authorities) {
    	ArrayList<String> authList = new ArrayList<String>();
        authList.add("ROLE_USER");
        InfoType_User user = this.selectUserInfo(userid);
        if(user == null) {
        	user = new InfoType_User( null, userid, password, username, department, telephone, email, authList);
        	saveUserInfo(user);
        	return true;
        }
        else {
        	return false;
        }
    }
    
    public boolean Update_UserInfo(String userid, String password, String username, String department, String telephone, String email, String authorities, String index) {
    	ArrayList<String> authList = new ArrayList<String>();
        authorities = authorities.trim();
        String[] roles = authorities.split(" ");
        for(int i=0; i<roles.length; i++) {
        	authList.add(roles[i]);
        }
        InfoType_User user = this.selectUserInfo(index);
        if(user != null) {
        	user.setUserID(userid);
        	user.setPassword(password);
        	user.setUsername(username);
        	user.setDepartment(department);
        	user.setTelephone(telephone);
        	user.setEmail(email);
        	user.setRoles(authList);
        	saveUserInfo(user);
        	return true;
        }
        else {
        	return false;
        }
    }
    
    public boolean Delete_UserInfo(String userid) {
    	InfoType_User user = selectUserInfo(userid);
    	if(user != null) {
    		removeUserInfo(user);
    		return true;
    	}
    	else {
    		return false;
    	}
    }

}