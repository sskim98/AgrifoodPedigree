package kaist.gs1.pms;

import org.springframework.data.repository.CrudRepository;

public interface RepositoryDao_Certificate extends CrudRepository<InfoType_Certificate, String> {
}
