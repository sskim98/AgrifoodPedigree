package kaist.gs1.pms;

import org.springframework.data.repository.CrudRepository;

public interface RepositoryDao_Code extends CrudRepository<InfoType_Code, String> {
}
