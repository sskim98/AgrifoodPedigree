package kaist.gs1.pms;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import kaist.gs1.pms.RepositoryDao_User;

@Component
public class Service_UserDetails implements UserDetailsService {

    @Resource
    private RepositoryDao_User userRepositoryDao;
    private static final Logger logger = Logger.getLogger(Service_UserDetails.class);
    private User userdetails;
    
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        boolean enabled = true;
        boolean accountNonExpired = true;
        boolean credentialsNonExpired = true;
        boolean accountNonLocked = true;
        InfoType_User peduser = getUserDetail(username);
        
        if(peduser == null) {
        	throw new UsernameNotFoundException("������ ������ ã�� �� �����ϴ�.");
        }
        
        userdetails = new User(
        		peduser.getUserID(), 
        		peduser.getPassword(),
            	enabled,
            	accountNonExpired,
            	credentialsNonExpired,
            	accountNonLocked,
            	getAuthorities(peduser.getRoles()));
            return userdetails;
    }

    public List<GrantedAuthority> getAuthorities(ArrayList<String> roles) {
        List<GrantedAuthority> authList = new ArrayList<GrantedAuthority>();
        for(int i=0; i<roles.size(); i++) {
	            authList.add(new SimpleGrantedAuthority(roles.get(i)));
        }
        return authList;
    }

    public InfoType_User getUserDetail(String userid) {
    	InfoType_User peduser = userRepositoryDao.findUserByUserID(userid);
        return peduser;
    }
}