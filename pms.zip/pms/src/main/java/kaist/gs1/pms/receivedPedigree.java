package kaist.gs1.pms;

import java.util.ArrayList;
import java.util.Collection;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
	

//@JacksonXmlRootElement(localName="pedigree", namespace="urn:epcGlobal:Pedigree:xsd:1")
public class receivedPedigree {
	
	@JsonInclude(JsonInclude.Include.NON_NULL) // serialization without null objects
	public DocumentInfoType documentInfo = null;
	@JsonInclude(JsonInclude.Include.NON_NULL) // serialization without null objects
	public String previousPedigree = null;
	@JsonInclude(JsonInclude.Include.NON_NULL) // serialization without null objects
	public ReceivingInfoType receivingInfo = null;
	@JsonInclude(JsonInclude.Include.NON_NULL) // serialization without null objects
	public SignatureInfoType signatureInfo = null;
	@JacksonXmlProperty(isAttribute = true)
	public String id = null;
	
	receivedPedigree(String sgtin) {
		//Document eventDoc = buildDocumentfromString(eventXml);
		this.id = sgtin;
		String[] array = sgtin.split("\\.");
		this.documentInfo = new DocumentInfoType();
		this.documentInfo.serialNumber = array[array.length-1];
		this.documentInfo.version = "version";
		this.previousPedigree = "previousPedigree";
		
		
		//transactionInfo
		//this.transactionInfo = new TransactionInfoType();
		
	}
	
	//@XmlRootElement(name = "LicenseNumber")
		public class LicenseNumber {
			String licenseNumber;
			@JacksonXmlProperty(isAttribute = true)
			String state;
			String agency;
		}
		//@XmlRootElement(name = "DocumentInfoType")
		public class DocumentInfoType {
			String serialNumber;
			String version;
			public String getSerialNumber() {
				return serialNumber;
			}
			public void setSerialNumber(String serialNumber) {
				this.serialNumber = serialNumber;
			}
			public String getVersion() {
				return version;
			}
			public void setVersion(String version) {
				this.version = version;
			}
		}
		//@XmlRootElement(name = "ForeignDataType")
		public class ForeignDataType {
			String serialNumbner;
			String mimeType;
			EncodingType encoding;
			String data;
		}
		//@XmlRootElement(name = "ItemInfoType")
		public  class ItemInfoType {
			private String lot;
			private String expirationDate;
			private String quantity;
			private String itemSerialNumber;
			public String getLot() {
				return lot;
			}
			public void setLot(String lot) {
				this.lot = lot;
			}
			public String getExpirationDate() {
				return expirationDate;
			}
			public void setExpirationDate(String expirationDate) {
				this.expirationDate = expirationDate;
			}
			public String getQuantity() {
				return quantity;
			}
			public void setQuantity(String quantity) {
				this.quantity = quantity;
			}
			public String getItemSerialNumber() {
				return itemSerialNumber;
			}
			public void setItemSerialNumber(String itemSerialNumber) {
				this.itemSerialNumber = itemSerialNumber;
			}
		}

		//@XmlRootElement(name = "ProductInfoType")
		public class ProductInfoType {
			
			private String drugName;
			
			private String manufacturer;
			
			//@JsonInclude(JsonInclude.Include.NON_NULL) // serialization without null objects
			//ProductCodeType productCode;
			
			private String dosageForm; // disuse for agrifood
			
			private String strength; // disuse for agrifood
			
			private String containerSize;

			public String getDrugName() {
				return drugName;
			}

			public void setDrugName(String drugName) {
				this.drugName = drugName;
			}

			public String getManufacturer() {
				return manufacturer;
			}

			public void setManufacturer(String manufacturer) {
				this.manufacturer = manufacturer;
			}

			public String getDosageForm() {
				return dosageForm;
			}

			public void setDosageForm(String dosageForm) {
				this.dosageForm = dosageForm;
			}

			public String getStrength() {
				return strength;
			}

			public void setStrength(String strength) {
				this.strength = strength;
			}

			public String getContainerSize() {
				return containerSize;
			}

			public void setContainerSize(String containerSize) {
				this.containerSize = containerSize;
			}
			
			
		}
		//@XmlRootElement(name = "TransactionInfoType")
		public class TransactionInfoType {
			PartnerInfoType senderInfo;
			PartnerInfoType recipientInfo;
			TransactionIdentifierType transactionIdentifier;
			TransactionIdentifierType altRransactionIdentifier;
			TransactionTypeType transactionType;
			String transactionDate;
		}
		//@XmlRootElement(name = "PartnerInfoType")
		public class PartnerInfoType {
			AddressType businessAddress;
			AddressType shippingAddress;
			PartnerIdType partnerId;
			LicenseNumber licenseNumber;
			ContactType contactInfo;
		}
		//@XmlRootElement(name = "AddressType")
		public class AddressType {
			String businessName;
			String street1;
			String street2;
			String city;
			String stateOrRegion;
			String postalCode;
			String country;
			AddressIdType AddressId;
		}
		//@XmlRootElement(name = "TransactionIdentifierType")
		public class TransactionIdentifierType {
			String identifier;
			TransactionIdentifierTypeType identifierType;
		}
		//@XmlRootElement(name = "ContactType")
		public class ContactType {
			String name;
			String title;
			String telephone;
			String email;
			String url;
		}
		//@XmlRootElement(name = "ReceivingInfoType")
		public class ReceivingInfoType {
			String dateReceived;//xs:date
			ItemInfoType itemInfo;
		}
		//@XmlRootElement(name = "PreviousProductType")
		public class PreviousProductType {
			String serialNumber;
			PreviousProductInfoType previousProductInfo;
			ItemInfoType itemInfo;
			ContactType contactInfo;
		}
		//@XmlRootElement(name = "SignatureInfoType")
		public class SignatureInfoType {
			ContactType signerInfo;
			String signatureDate;
			SignatureMeaningType signatureMeaning;
		}
		//@XmlRootElement(name = "PreviousProductInfoType")
		public class PreviousProductInfoType {
			String drugName;
			String manufacturer;
			ProductCodeType productCode;
		}
		//@XmlRootElement(name = "ProductCodeType")
		public class ProductCodeType {
			String type;
		}
		//@XmlRootElement(name = "PartnerIdType")
		public class PartnerIdType {
			String partnerId;
			@JacksonXmlProperty(isAttribute = true)
			String type;
		}
		//@XmlRootElement(name = "AddressIdType")
		public class AddressIdType {
			String addressId;
			@JacksonXmlProperty(isAttribute = true)
			String type;
		}
		//@XmlRootElement(name = "TransactionIdentifierTypeType")
		public enum TransactionIdentifierTypeType {
			InvoiceNumber, PurchaseOrderNumber, ShippingNumber, ReturnAuthorizationNumber, Other
		}
		//@XmlRootElement(name = "SignatureMeaningType")
		public enum SignatureMeaningType {
			Certified, Received, Authenticated, ReceivedAndAuthenticated
		}
		//@XmlRootElement(name = "TransactionTypeType")
		public enum TransactionTypeType {
			Sale, Return, Transfer, Other
		}
		//@XmlRootElement(name = "ProductCodeValueTypeType")
		public enum ProductCodeValueTypeType {
			NDC442, NDC532, NDC541, NDC542, GTIN
		}
		//@XmlRootElement(name = "EncodingType")
		public enum EncodingType {
			base64binary
		}
		//@XmlRootElement(name = "PartnerIdValueTypeType")
		public enum PartnerIdValueTypeType {
			GLN
		}
		//@XmlRootElement(name = "AddressIdValueTypeType")
		public enum AddressIdValueTypeType {
			GLN
		}
		//@XmlRootElement(name = "AltPedigree")
		public class AltPedigree {
			@JacksonXmlProperty(isAttribute = true)
			boolean wasRepackaged;
			String serialNumbner;
			String mimeType;
			EncodingType encoding;
			String data;
		}
		//@XmlRootElement(name = "Attachment")
		public class Attachment {
			String serialNumbner;
			String mimeType;
			EncodingType encoding;
			String data;
		}
		public DocumentInfoType getDocumentInfo() {
			return documentInfo;
		}
		public void setDocumentInfo(DocumentInfoType documentInfo) {
			this.documentInfo = documentInfo;
		}
		public String getPreviousPedigree() {
			return previousPedigree;
		}
		public void setPreviousPedigree(String previousPedigree) {
			this.previousPedigree = previousPedigree;
		}
		public ReceivingInfoType getReceivingInfo() {
			return receivingInfo;
		}
		public void setReceivingInfo(ReceivingInfoType receivingInfo) {
			this.receivingInfo = receivingInfo;
		}
		public SignatureInfoType getSignatureInfo() {
			return signatureInfo;
		}
		public void setSignatureInfo(SignatureInfoType signatureInfo) {
			this.signatureInfo = signatureInfo;
		}
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}

}



